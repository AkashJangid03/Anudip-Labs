package Lab09;

public class Shape {
    public double getArea() {
        return 0.0;
    }
}
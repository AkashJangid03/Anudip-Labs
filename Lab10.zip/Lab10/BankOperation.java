package Lab10;

public interface BankOperation {
    double getBalance();
    void deposit(double amount);
    void withdraw(double amount);
}
